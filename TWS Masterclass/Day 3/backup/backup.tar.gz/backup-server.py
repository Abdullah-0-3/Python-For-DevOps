import shutil
import os

def create_backup(source_path, destination_path):
    backup_name = os.path.join(destination_path, "backup1")
    shutil.make_archive(backup_name, 'gztar', source_path)
    print(f"Backup created at {backup_name}")

source_path = "D:\Works\Alnafi\DevOps\Python For DevOps\Day 3\Day 3"
destination_path = "D:\Works\Alnafi\DevOps\Python For DevOps\Day 3\\backups"

create_backup(source_path, destination_path)